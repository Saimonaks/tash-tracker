// api.js — единственное место, где фронтенд получает данные
const API_BASE = 'data'; // В ЛР № 10: '/api'

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}/${path}`, options);
  if (!res.ok) {
    throw new Error(`Ошибка загрузки: ${res.status}`);
  }
  return res.json();
}

async function getTasks() {
  return request('tasks.json'); // В ЛР № 10: 'tasks'
}

async function getTask(id) {
  const items = await getTasks();
  return items.find((t) => t.id === id) ?? null;
}