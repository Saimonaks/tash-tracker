const path = require('path');
const express = require('express');
const tasksRouter = require('./routes/tasks');

const app = express();

// Раздача статических файлов фронтенда из папки www
app.use(express.static(path.join(__dirname, '..', 'www')));

// Проверка работоспособности сервера
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date() });
});

// Маршруты API для задач
app.use('/api/tasks', tasksRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сайт и API запущены: http://localhost:${PORT}`);
});