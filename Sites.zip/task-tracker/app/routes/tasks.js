const express = require('express');
const tasks = require('../data/tasks.json');

const router = express.Router();

// GET /api/tasks?category=study&search=отчёт&sort=priority
router.get('/', (req, res) => {
  const { category, search, sort } = req.query;
  let items = [...tasks];

  if (category && category !== 'all') {
    items = items.filter((t) => t.category === category);
  }

  if (search) {
    const q = search.trim().toLowerCase();
    items = items.filter((t) => t.title.toLowerCase().includes(q));
  }

  if (sort === 'priority') {
    items.sort((a, b) => b.priority - a.priority);
  } else if (sort === 'deadline') {
    items.sort((a, b) => a.deadline.localeCompare(b.deadline));
  } else if (sort === 'title') {
    items.sort((a, b) => a.title.localeCompare(b.title, 'ru'));
  }

  res.json(items);
});

// GET /api/tasks/1
router.get('/:id', (req, res) => {
  const item = tasks.find((t) => t.id === Number(req.params.id));
  if (!item) {
    return res.status(404).json({ error: 'Задача не найдена' });
  }
  res.json(item);
});

module.exports = router;